package com.bedrockminer.tutorial.block;

public final class ModBlocks {

	public static final void init() {
	}

}
